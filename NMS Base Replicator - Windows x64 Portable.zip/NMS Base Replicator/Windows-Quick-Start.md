# NMS Base Replicator for Windows

Extract the whole Windows x64 ZIP. Open NMS Base Replicator.exe from the
extracted folder and keep its _internal folder alongside it. The wizard
ships with its own Python runtime.

Choose a workflow, load the input files, select the bases, then review the
object counts and destination address. Choose a new JSON output filename.
The wizard also writes a matching .nmsbase file. Existing files are protected.

## Python batch examples

These scripts take arguments and require Python 3.10 or later. Run them from
Command Prompt with paths and names in quotes. Set NMS_PYTHON to the full
path to python.exe if the python command is unavailable. These examples
assume the files are in the current folder. Use a new output prefix each time.

    python main.py list "save.json"
    one-gamesave.bat "save.json" 16 55 "one-save-result"
    two-gamesaves.bat "source.json" 16 "destination.json" 55 "two-save-result"
    nmsbase-to-gamesave.bat "source.nmsbase" "destination.json" 55 "base-file-result"

Replace 16 and 55 with the list numbers from your own files, or use exact
unique base names. For two saves, run the list command separately on each.
The output prefix is a filename without an extension.

See README.md for the Python CLI, data format and NMSE workflow.
